// src/api/api.js
const API_URL = "http://localhost:8080";

// 🔹 LOGIN
export async function loginUser(credentials) {
  const response = await fetch(`${API_URL}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(credentials),
  });

  if (!response.ok) {
    throw new Error("Error al iniciar sesión");
  }

  return response.json(); // devuelve el token
}

// 🔹 REGISTRO (crea usuario con /api/users)
export async function registerUser(userData) {
  const response = await fetch(`${API_URL}/api/users`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      // si tu SecurityConfig protege /api/users, necesitas token:
      "Authorization": `Bearer ${localStorage.getItem("token") || ""}`,
    },
    body: JSON.stringify(userData),
  });

  if (!response.ok) {
    throw new Error("Error al registrar usuario");
  }

  return response.json();
}
