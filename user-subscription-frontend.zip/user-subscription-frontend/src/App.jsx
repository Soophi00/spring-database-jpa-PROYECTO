import Login from "./pages/Login";

export default function App() {
  return (
    <div>
      <Login />
    </div>
  );
}
