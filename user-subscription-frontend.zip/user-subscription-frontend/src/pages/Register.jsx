import { useState } from "react";
import { registerUser } from "../api/api";
import "./Login.css"; // reutilizamos el mismo estilo

export default function Register() {
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    birthDate: "",
  });
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Enviamos los datos al backend
      await registerUser({
        firstName: form.firstName,
        lastName: form.lastName,
        email: form.email,
        password: form.password,
        roles: "ROLE_USER",
        birthDate: form.birthDate,
      });
      setMessage("✅ Usuario registrado correctamente!");
    } catch (err) {
      console.error(err);
      setMessage("❌ Error al registrar usuario.");
    }
  };

  return (
    <div className="container">
      <h1>📝 Registro</h1>
      <form onSubmit={handleSubmit}>
        <label>Nombre</label>
        <input
          type="text"
          name="firstName"
          placeholder="Tu nombre"
          value={form.firstName}
          onChange={handleChange}
          required
        />

        <label>Apellido</label>
        <input
          type="text"
          name="lastName"
          placeholder="Tu apellido"
          value={form.lastName}
          onChange={handleChange}
          required
        />

        <label>Correo electrónico</label>
        <input
          type="email"
          name="email"
          placeholder="correo@ejemplo.com"
          value={form.email}
          onChange={handleChange}
          required
        />

        <label>Contraseña</label>
        <input
          type="password"
          name="password"
          placeholder="********"
          value={form.password}
          onChange={handleChange}
          required
        />

        <label>Fecha de nacimiento</label>
        <input
          type="date"
          name="birthDate"
          value={form.birthDate}
          onChange={handleChange}
          required
        />

        <button type="submit">Registrar</button>
      </form>

      <footer>Desarrollado por <b>sv.edu.udb</b> © 2025</footer>
      <p style={{ textAlign: "center", marginTop: "10px" }}>{message}</p>
    </div>
  );
}
