import { useState } from "react";
import { loginUser } from "../api/api";
import "./Login.css"; // ✅ importa el nuevo estilo

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = await loginUser({ email, password });
      localStorage.setItem("token", data.token);
      setMessage(`✅ Bienvenido ${email}!`);
    } catch {
      setMessage("❌ Error al iniciar sesión.");
    }
  };

  return (
    <div className="container">
      <h1>💾 Login</h1>
      <form onSubmit={handleSubmit}>
        <label>Correo electrónico</label>
        <input
          type="email"
          value={email}
          placeholder="ejemplo@correo.com"
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <label>Contraseña</label>
        <input
          type="password"
          value={password}
          placeholder="********"
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button type="submit">Entrar</button>
      </form>
      <footer>Desarrollado por <b>sv.edu.udb</b> © 2025</footer>
      <p style={{ textAlign: "center", marginTop: "10px" }}>{message}</p>
    </div>
  );
}
